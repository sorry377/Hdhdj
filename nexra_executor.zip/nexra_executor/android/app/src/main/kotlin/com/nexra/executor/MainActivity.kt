package com.nexra.executor

import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    private val CHANNEL = "nexra/executor"
    private var targetPackage: String? = null
    private var isAttached = false
    private var antiBanLoaded = false
    private var antiKickLoaded = false

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL)
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "getRobloxApps" -> {
                        result.success(getRobloxRelatedApps())
                    }
                    "attachProcess" -> {
                        val pkg = call.argument<String>("package")
                        targetPackage = pkg
                        isAttached = attachToProcess(pkg)
                        result.success(isAttached)
                    }
                    "loadAntiBan" -> {
                        antiBanLoaded = loadAntiBanModule()
                        result.success(antiBanLoaded)
                    }
                    "loadAntiKick" -> {
                        antiKickLoaded = loadAntiKickModule()
                        result.success(antiKickLoaded)
                    }
                    "executeLua" -> {
                        val script = call.argument<String>("script") ?: ""
                        val packageName = call.argument<String>("package") ?: targetPackage ?: ""
                        val output = executeLuaScript(packageName, script)
                        result.success(output)
                    }
                    else -> result.notImplemented()
                }
            }
    }

    private fun getRobloxRelatedApps(): List<Map<String, String>> {
        val pm = packageManager
        val apps = mutableListOf<Map<String, String>>()
        try {
            val packages = pm.getInstalledApplications(PackageManager.GET_META_DATA)
            for (app in packages) {
                val label = app.loadLabel(pm).toString()
                val pkg = app.packageName
                if (label.contains("roblox", ignoreCase = true) ||
                    pkg.contains("roblox", ignoreCase = true)
                ) {
                    apps.add(
                        mapOf(
                            "name" to label,
                            "package" to pkg
                        )
                    )
                }
            }
        } catch (e: Exception) {
            // fallback
            apps.add(mapOf("name" to "Roblox", "package" to "com.roblox.client"))
        }

        if (apps.isEmpty()) {
            apps.add(mapOf("name" to "Roblox", "package" to "com.roblox.client"))
            apps.add(mapOf("name" to "Roblox (Beta)", "package" to "com.roblox.client.beta"))
        }
        return apps
    }

    /**
     * Attach to target process.
     * Production: use ptrace / Frida / custom injector.
     */
    private fun attachToProcess(packageName: String?): Boolean {
        if (packageName.isNullOrEmpty()) return false
        // TODO: Real attach logic here
        // Example approaches:
        // 1. Frida Gadget injection
        // 2. Custom ptrace-based injector
        // 3. Shared memory / binder hook
        return true
    }

    /**
     * Load Anti-Ban payload into target process.
     */
    private fun loadAntiBanModule(): Boolean {
        // TODO: Inject anti-ban .so or memory patch
        // Typical targets: detection functions, signature scans, heartbeat
        return true
    }

    /**
     * Load Anti-Kick payload.
     */
    private fun loadAntiKickModule(): Boolean {
        // TODO: Hook kick-related functions / remote events
        return true
    }

    /**
     * Execute Lua script inside the attached Roblox process.
     * Supports full Lua UI (ScreenGui, Frame, TextButton, etc.)
     */
    private fun executeLuaScript(packageName: String, script: String): String {
        if (!isAttached) {
            return "[ERROR] Process not attached"
        }
        if (script.isBlank()) {
            return "[ERROR] Empty script"
        }

        // TODO: Real execution path
        // 1. Send script via named pipe / unix socket / shared memory
        //    to the injected Lua bridge inside Roblox process
        // 2. Bridge calls loadstring / task.spawn inside Roblox Lua VM
        // 3. Capture print / warn / error and return here

        // Simulated success response for UI testing
        return buildString {
            appendLine("[NEXRA] Script received (${script.length} bytes)")
            appendLine("[NEXRA] Anti-Ban  : ${if (antiBanLoaded) "ACTIVE" else "OFF"}")
            appendLine("[NEXRA] Anti-Kick : ${if (antiKickLoaded) "ACTIVE" else "OFF"}")
            appendLine("[NEXRA] Target    : $packageName")
            appendLine("[NEXRA] Status    : EXECUTED")
            appendLine("---")
            appendLine("Output stream ready. Lua UI supported.")
        }
    }
}
