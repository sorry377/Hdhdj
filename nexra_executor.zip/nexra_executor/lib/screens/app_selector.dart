import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'loading_screen.dart';

class AppSelectorScreen extends StatefulWidget {
  const AppSelectorScreen({super.key});

  @override
  State<AppSelectorScreen> createState() => _AppSelectorScreenState();
}

class _AppSelectorScreenState extends State<AppSelectorScreen> {
  static const platform = MethodChannel('nexra/executor');
  List<Map<String, dynamic>> apps = [];
  bool isLoading = true;
  String errorMsg = '';

  @override
  void initState() {
    super.initState();
    _loadInstalledApps();
  }

  Future<void> _loadInstalledApps() async {
    try {
      final result = await platform.invokeMethod('getRobloxApps');
      setState(() {
        apps = List<Map<String, dynamic>>.from(
          (result as List).map((e) => Map<String, dynamic>.from(e)),
        );
        isLoading = false;
      });
    } catch (e) {
      setState(() {
        isLoading = false;
        errorMsg = e.toString();
        // Fallback demo list for testing without native
        apps = [
          {'name': 'Roblox', 'package': 'com.roblox.client'},
          {'name': 'Roblox (Beta)', 'package': 'com.roblox.client.beta'},
        ];
      });
    }
  }

  void _selectApp(Map<String, dynamic> app) {
    Navigator.push(
      context,
      PageRouteBuilder(
        pageBuilder: (_, __, ___) => LoadingScreen(
          packageName: app['package'] ?? '',
          appName: app['name'] ?? 'Unknown',
        ),
        transitionsBuilder: (_, animation, __, child) {
          return FadeTransition(opacity: animation, child: child);
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('NEXRA EXECUTOR'),
        centerTitle: true,
      ),
      body: isLoading
          ? const Center(
              child: CircularProgressIndicator(
                color: Color(0xFF00FF9D),
                strokeWidth: 2.5,
              ),
            )
          : apps.isEmpty
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.warning_amber_rounded,
                          color: Colors.orange, size: 48),
                      const SizedBox(height: 16),
                      const Text(
                        'No Roblox apps found',
                        style: TextStyle(color: Colors.white70, fontSize: 16),
                      ),
                      if (errorMsg.isNotEmpty)
                        Padding(
                          padding: const EdgeInsets.all(16),
                          child: Text(
                            errorMsg,
                            style: const TextStyle(color: Colors.redAccent, fontSize: 12),
                            textAlign: TextAlign.center,
                          ),
                        ),
                    ],
                  ),
                )
              : ListView.builder(
                  padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
                  itemCount: apps.length,
                  itemBuilder: (context, index) {
                    final app = apps[index];
                    return Container(
                      margin: const EdgeInsets.only(bottom: 10),
                      decoration: BoxDecoration(
                        color: const Color(0xFF111111),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: const Color(0xFF1A1A1A)),
                      ),
                      child: ListTile(
                        contentPadding: const EdgeInsets.symmetric(
                            horizontal: 16, vertical: 8),
                        leading: Container(
                          width: 48,
                          height: 48,
                          decoration: BoxDecoration(
                            color: const Color(0xFF0A0A0A),
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(color: const Color(0xFF00FF9D).withOpacity(0.3)),
                          ),
                          child: const Icon(Icons.games_rounded,
                              color: Color(0xFF00FF9D), size: 26),
                        ),
                        title: Text(
                          app['name'] ?? 'Unknown',
                          style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w600,
                            fontSize: 16,
                          ),
                        ),
                        subtitle: Text(
                          app['package'] ?? '',
                          style: const TextStyle(color: Colors.grey, fontSize: 12),
                        ),
                        trailing: const Icon(Icons.arrow_forward_ios_rounded,
                            color: Color(0xFF00FF9D), size: 16),
                        onTap: () => _selectApp(app),
                      ),
                    );
                  },
                ),
    );
  }
}
