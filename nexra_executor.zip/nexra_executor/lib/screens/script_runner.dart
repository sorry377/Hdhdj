import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class ScriptRunnerScreen extends StatefulWidget {
  final String packageName;
  final String appName;

  const ScriptRunnerScreen({
    super.key,
    required this.packageName,
    required this.appName,
  });

  @override
  State<ScriptRunnerScreen> createState() => _ScriptRunnerScreenState();
}

class _ScriptRunnerScreenState extends State<ScriptRunnerScreen> {
  static const platform = MethodChannel('nexra/executor');
  final TextEditingController _luaController = TextEditingController();
  final ScrollController _logScrollController = ScrollController();
  String outputLog = '';
  bool isRunning = false;

  Future<void> _executeScript() async {
    final script = _luaController.text.trim();
    if (script.isEmpty) return;

    setState(() {
      isRunning = true;
      outputLog += '>>> Executing script...\n';
    });
    _scrollLogToBottom();

    try {
      final result = await platform.invokeMethod('executeLua', {
        'package': widget.packageName,
        'script': script,
      });
      setState(() {
        outputLog += '${result.toString()}\n';
        isRunning = false;
      });
    } catch (e) {
      setState(() {
        outputLog += '[ERROR] $e\n';
        isRunning = false;
      });
    }
    _scrollLogToBottom();
  }

  void _scrollLogToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_logScrollController.hasClients) {
        _logScrollController.animateTo(
          _logScrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 200),
          curve: Curves.easeOut,
        );
      }
    });
  }

  void _clearScript() {
    _luaController.clear();
  }

  void _clearLog() {
    setState(() => outputLog = '');
  }

  @override
  void dispose() {
    _luaController.dispose();
    _logScrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.appName),
        actions: [
          IconButton(
            tooltip: 'Clear script',
            icon: const Icon(Icons.clear_all_rounded, color: Colors.white54),
            onPressed: _clearScript,
          ),
        ],
      ),
      body: Column(
        children: [
          // Lua editor
          Expanded(
            flex: 3,
            child: Container(
              margin: const EdgeInsets.fromLTRB(12, 12, 12, 8),
              decoration: BoxDecoration(
                color: const Color(0xFF0F0F0F),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: const Color(0xFF1E1E1E)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                    decoration: const BoxDecoration(
                      color: Color(0xFF151515),
                      borderRadius: BorderRadius.vertical(top: Radius.circular(12)),
                    ),
                    child: const Text(
                      'LUA SCRIPT',
                      style: TextStyle(
                        color: Color(0xFF00FF9D),
                        fontSize: 11,
                        fontWeight: FontWeight.w600,
                        letterSpacing: 1.5,
                      ),
                    ),
                  ),
                  Expanded(
                    child: TextField(
                      controller: _luaController,
                      maxLines: null,
                      expands: true,
                      style: const TextStyle(
                        color: Color(0xFFE0E0E0),
                        fontFamily: 'monospace',
                        fontSize: 13.5,
                        height: 1.45,
                      ),
                      cursorColor: const Color(0xFF00FF9D),
                      decoration: const InputDecoration(
                        contentPadding: EdgeInsets.all(14),
                        hintText:
                            '-- Paste your Lua script here\n\nprint("Hello from NEXRA")\n\n-- Supports full Lua UI\n-- ScreenGui, Frame, TextButton, etc.',
                        hintStyle: TextStyle(
                          color: Colors.white24,
                          fontFamily: 'monospace',
                          fontSize: 13,
                        ),
                        border: InputBorder.none,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),

          // Execute button
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            child: SizedBox(
              width: double.infinity,
              height: 50,
              child: ElevatedButton(
                onPressed: isRunning ? null : _executeScript,
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF00FF9D),
                  foregroundColor: Colors.black,
                  disabledBackgroundColor: const Color(0xFF00FF9D).withOpacity(0.4),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  elevation: 0,
                ),
                child: isRunning
                    ? const SizedBox(
                        width: 22,
                        height: 22,
                        child: CircularProgressIndicator(
                          strokeWidth: 2.5,
                          color: Colors.black,
                        ),
                      )
                    : const Text(
                        'EXECUTE',
                        style: TextStyle(
                          fontWeight: FontWeight.w800,
                          fontSize: 15,
                          letterSpacing: 1.5,
                        ),
                      ),
              ),
            ),
          ),

          // Output log
          Expanded(
            flex: 2,
            child: Container(
              width: double.infinity,
              margin: const EdgeInsets.fromLTRB(12, 10, 12, 12),
              decoration: BoxDecoration(
                color: const Color(0xFF0A0A0A),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: const Color(0xFF1A1A1A)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                    decoration: const BoxDecoration(
                      color: Color(0xFF121212),
                      borderRadius: BorderRadius.vertical(top: Radius.circular(12)),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text(
                          'OUTPUT',
                          style: TextStyle(
                            color: Colors.white38,
                            fontSize: 11,
                            fontWeight: FontWeight.w600,
                            letterSpacing: 1.5,
                          ),
                        ),
                        GestureDetector(
                          onTap: _clearLog,
                          child: const Text(
                            'CLEAR',
                            style: TextStyle(
                              color: Colors.white24,
                              fontSize: 11,
                              letterSpacing: 1,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Expanded(
                    child: SingleChildScrollView(
                      controller: _logScrollController,
                      padding: const EdgeInsets.all(12),
                      child: Text(
                        outputLog.isEmpty ? 'Waiting for output...' : outputLog,
                        style: TextStyle(
                          color: outputLog.isEmpty
                              ? Colors.white24
                              : const Color(0xFF00FF9D),
                          fontFamily: 'monospace',
                          fontSize: 12.5,
                          height: 1.4,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
