import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'script_runner.dart';

class LoadingScreen extends StatefulWidget {
  final String packageName;
  final String appName;

  const LoadingScreen({
    super.key,
    required this.packageName,
    required this.appName,
  });

  @override
  State<LoadingScreen> createState() => _LoadingScreenState();
}

class _LoadingScreenState extends State<LoadingScreen>
    with SingleTickerProviderStateMixin {
  static const platform = MethodChannel('nexra/executor');
  String status = 'Initializing...';
  double progress = 0.0;
  late AnimationController _pulseController;

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    )..repeat(reverse: true);
    _startInjection();
  }

  @override
  void dispose() {
    _pulseController.dispose();
    super.dispose();
  }

  Future<void> _startInjection() async {
    try {
      // Step 1: Attach
      setState(() {
        status = 'Attaching to process...';
        progress = 0.15;
      });
      await platform.invokeMethod('attachProcess', {
        'package': widget.packageName,
      });
      await Future.delayed(const Duration(milliseconds: 900));

      // Step 2: Anti-Ban
      setState(() {
        status = 'Loading Anti-Ban module...';
        progress = 0.45;
      });
      await platform.invokeMethod('loadAntiBan');
      await Future.delayed(const Duration(milliseconds: 1100));

      // Step 3: Anti-Kick
      setState(() {
        status = 'Loading Anti-Kick module...';
        progress = 0.75;
      });
      await platform.invokeMethod('loadAntiKick');
      await Future.delayed(const Duration(milliseconds: 1000));

      // Step 4: Ready
      setState(() {
        status = 'Injection complete';
        progress = 1.0;
      });
      await Future.delayed(const Duration(milliseconds: 700));

      if (mounted) {
        Navigator.pushReplacement(
          context,
          PageRouteBuilder(
            pageBuilder: (_, __, ___) => ScriptRunnerScreen(
              packageName: widget.packageName,
              appName: widget.appName,
            ),
            transitionsBuilder: (_, animation, __, child) {
              return FadeTransition(opacity: animation, child: child);
            },
          ),
        );
      }
    } catch (e) {
      setState(() {
        status = 'Error: $e';
        progress = 0.0;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: double.infinity,
        height: double.infinity,
        color: const Color(0xFF0A0A0A),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ScaleTransition(
              scale: Tween<double>(begin: 0.96, end: 1.04).animate(
                CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
              ),
              child: const Text(
                'NEXRA',
                style: TextStyle(
                  color: Color(0xFF00FF9D),
                  fontSize: 42,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 8,
                ),
              ),
            ),
            const SizedBox(height: 12),
            Text(
              widget.appName.toUpperCase(),
              style: const TextStyle(
                color: Colors.white38,
                fontSize: 13,
                letterSpacing: 2,
              ),
            ),
            const SizedBox(height: 56),
            SizedBox(
              width: 240,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(4),
                child: LinearProgressIndicator(
                  value: progress,
                  backgroundColor: const Color(0xFF1A1A1A),
                  color: const Color(0xFF00FF9D),
                  minHeight: 5,
                ),
              ),
            ),
            const SizedBox(height: 24),
            Text(
              status,
              style: const TextStyle(
                color: Colors.white70,
                fontSize: 15,
                fontWeight: FontWeight.w400,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              '${(progress * 100).toInt()}%',
              style: const TextStyle(
                color: Color(0xFF00FF9D),
                fontSize: 12,
                fontFamily: 'monospace',
              ),
            ),
          ],
        ),
      ),
    );
  }
}
