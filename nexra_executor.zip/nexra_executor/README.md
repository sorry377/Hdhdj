# NEXRA Executor

Roblox Lua Script Executor for Android.

## Features

- Select Roblox / Roblox-related apps on device
- Attach process
- Load Anti-Ban module
- Load Anti-Kick module
- Full Lua script editor
- Execute scripts with output log
- Supports Lua UI (ScreenGui, Frame, TextButton, TextLabel, etc.)

## Project Structure

```
nexra_executor/
├── lib/
│   ├── main.dart
│   └── screens/
│       ├── app_selector.dart
│       ├── loading_screen.dart
│       └── script_runner.dart
├── android/
│   └── app/src/main/
│       ├── AndroidManifest.xml
│       └── kotlin/com/nexra/executor/
│           └── MainActivity.kt
├── pubspec.yaml
└── README.md
```

## How to Build

1. Install Flutter SDK
2. Open terminal in this folder
3. Run:
   ```bash
   flutter pub get
   flutter build apk --release
   ```
4. APK will be at:
   `build/app/outputs/flutter-apk/app-release.apk`

## Native Side (Important)

`MainActivity.kt` currently contains working UI + MethodChannel skeleton.

Real injection requires you to implement:

1. **Process Attach**
   - Frida Gadget
   - Custom ptrace injector
   - Or Magisk module

2. **Anti-Ban / Anti-Kick**
   - Memory patches / function hooks against detection

3. **Lua Bridge**
   - Inject a small native library that exposes Lua execution
   - Communicate via Unix socket / shared memory / binder
   - Call `loadstring` / `task.spawn` inside Roblox Lua VM

## MethodChannel API

| Method          | Args                          | Description                    |
|-----------------|-------------------------------|--------------------------------|
| getRobloxApps   | -                             | List Roblox packages           |
| attachProcess   | package                       | Attach to target process       |
| loadAntiBan     | -                             | Load anti-ban payload          |
| loadAntiKick    | -                             | Load anti-kick payload         |
| executeLua      | package, script               | Run Lua script                 |

## Notes

- Root / Magisk recommended for reliable injection
- QUERY_ALL_PACKAGES permission is required to list apps
- This is a complete Flutter + Kotlin skeleton ready for native injector integration
